package com.cg.payroll.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;


@Controller
public class EmployeeController {
	
	public EmployeeController() {
		System.out.println("Inside EmployeeController()");
	}
	
	@Autowired
	PayrollServices service;
	
	
	//adding a employee
	@RequestMapping(value="add" , method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Employee emp)
	{
		return "first";
		
	}
	
	@RequestMapping(value="putData", method=RequestMethod.POST)
	public ModelAndView dataAdd(@ModelAttribute("my") Employee emp) throws PayrollServicesDownException, SQLException, EmployeeDetailsNotFoundException
	{
		int empId = service.acceptEmployeeDetails(emp);
		return new ModelAndView("added","employee",empId);
		
	}
	
	// retrieving all employees
	@RequestMapping(value="showAll",method=RequestMethod.GET)
	public ModelAndView showMobiles() throws PayrollServicesDownException, SQLException
	{	
		List<Employee> allEmployees	= service.getAllEmployeeDetails();
		return new ModelAndView("list","empList",allEmployees);
	}
	
	
	
	//searching trainee
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String searchData(@ModelAttribute ("data") Employee emp)
	{
		return "employeeSearch";
	}
	
	@RequestMapping(value="searchEmployee", method=RequestMethod.POST)
	public ModelAndView searchTrainee(@ModelAttribute("data") Employee emp) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		int empId = emp.getEmpId();
		List<Employee> mySearch = service.getEmployeeDetails(empId);
		return new ModelAndView("show", "empList", mySearch);
	
	}
	
		
	//directed to delete
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String traineeRemove(@ModelAttribute("mySearch") Employee emp)
	{
		return "removeEmployee";
		
	}
	
	//delete
	@RequestMapping(value="deleteEmployee", method=RequestMethod.POST)
	public ModelAndView removeData(@ModelAttribute("mySearch") Employee emp) throws SQLException
	{
		int empId = emp.getEmpId();
		service.removeEmployee(empId);
		return new ModelAndView("removeSucess","employee",empId);
		
	}

	// directed to update jsp
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String update(@RequestParam("id") int id,Map<String, Object> model, @ModelAttribute ("my") Employee emp) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		emp = service.findEmployee(id);
		model.put("my", emp);
		return "updateList";
		
	}
	
	
	//update
	@RequestMapping(value ="updateData" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("my") Employee emp) throws SQLException
	{
		service.updateEmployee(emp);
		return "updateSuccess";
		
	}
	
	
	
}
