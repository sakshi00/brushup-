package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.payroll.beans.Employee;

@Repository("dao")
public class PayrollDAOServiceImpl implements PayrollDAOServices
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmpId();
	}

	

	@Override
	public void deleteEmployee(int employeeId) throws SQLException {
		entityManager.remove(entityManager.find(Employee.class, employeeId));
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getEmployee(int employeeId) throws SQLException{
		return entityManager.createQuery("From Employee where employeeId="+employeeId).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		return entityManager.createQuery("From Employee").getResultList();
	}

	@Override
	public Employee findEmployee(int id){
		return entityManager.find(Employee.class, id);
	}
	
	@Override
	public void updateEmployee(Employee employee) throws SQLException{
		
		//Employee employee2 =entityManager.find(Employee.class, employee.getEmpId());
		entityManager.merge(employee);
		/*entityManager.getTransaction().commit();*/
		/*Query queryFour = entityManager.createQuery("Update Employee Set firstName=:FIRSTNAME,lastName=:LASTNAME, mobile=:MOBILE, pan=:PAN, email=:EMAIL, yearlyInvestment=:YEARLYINVESTMENT, bankDetails.accountNo=:ACCOUNTNO, bankDetails.bankName=:BANKNAME,bankDetails.bankIFSCCode=:BANKIFSCCODE,salary.basicSalary=:BASICSALARY where employeeId=:employeeId");
		queryFour.setParameter("employeeId", employee.getEmpId());
		queryFour.setParameter("firstName", employee.getFirstName());
		queryFour.setParameter("lastName", employee.getLastName());
		queryFour.setParameter("mobile", employee.getMobile());
		queryFour.setParameter("pan", employee.getPan());
		queryFour.setParameter("email", employee.getEmail());
		queryFour.setParameter("yearlyInvestment", employee.getYearlyInvestment());
		queryFour.setParameter("accountNo", employee.getBankDetails().getAccountNo());
		queryFour.setParameter("bankName", employee.getBankDetails().getBankName());
		queryFour.setParameter("bankIFSCCode", employee.getBankDetails().getBankIFSCCode());
		queryFour.setParameter("basicSalary", employee.getSalary().getBasicSalary());

		queryFour.executeUpdate();*/
		
	}

}
