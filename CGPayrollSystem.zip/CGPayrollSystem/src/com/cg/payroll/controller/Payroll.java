package com.cg.payroll.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class Payroll {
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Payroll pyr){
		
		
		return "addEmployee";
		
	}
	
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView dataAdd(@ModelAttribute("my") Payroll pyr) {
		
		
		return new ModelAndView("success");
		
		
	
}

}
