package com.cg.payroll.beans;

import javax.persistence.Embeddable;


@Embeddable
public class BankDetails

{
	private int accountNo;
	private String bankName,bankIFSCCode;
	
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankIFSCCode() {
		return bankIFSCCode;
	}
	public void setBankIFSCCode(String bankIFSCCode) {
		this.bankIFSCCode = bankIFSCCode;
	}
	
	
	@Override
	public String toString() {
		return "BankDetails [accountNo=" + accountNo + ", bankName=" + bankName
				+ ", bankIFSCCode=" + bankIFSCCode + "]";
	}
	
	
	
}




